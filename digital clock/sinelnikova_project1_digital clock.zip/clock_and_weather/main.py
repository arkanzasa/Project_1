def main():
    from clock import run_clock
    run_clock()

if __name__ == "__main__":
    main()
